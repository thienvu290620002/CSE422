﻿// Interfaces/IPrintable.cs
namespace Lab3_VoThienVu_CSE422.Interfaces
{
    internal interface IPrintable
    {
        void PrintDetails();
    }
}